package com.dam2.simondice

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun iniciarPartida(){
        print("Ha iniciado la partida")
        Log.d("Estado", "Estoy en onCreate")
        }
    }





}